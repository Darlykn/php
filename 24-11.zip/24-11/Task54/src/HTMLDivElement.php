<?php

namespace App\Task54;

class HTMLDivElement extends HTMLPairElement {
    public function getTagName() {
        return 'div';
    }
}
