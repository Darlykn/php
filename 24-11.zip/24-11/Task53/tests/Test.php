<?php

namespace App\Tests;

use App\ChildOfChild;
use PHPUnit\Framework\TestCase;

class Test extends TestCase
{
    public function test()
    {
        $obj = new ChildOfChild();
        $this->assertTrue($obj->isInstanceOF('App\Base'));
        $this->assertFalse($obj->isInstanceOf('Base'));
        $this->assertTrue($obj->isInstanceOf('App\FirstChild'));
        $this->assertTrue($obj->isInstanceOf('App\ChildOfChild'));
    }
}
