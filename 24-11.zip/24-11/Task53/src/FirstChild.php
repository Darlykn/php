<?php

namespace App;

class FirstChild extends Base
{
}
