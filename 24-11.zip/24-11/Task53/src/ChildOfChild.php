<?php

namespace App;

class ChildOfChild extends FirstChild
{
}
