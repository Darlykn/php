<?php

namespace App\Exceptions;

class FileException extends \Exception {

}
