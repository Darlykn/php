<?php

namespace App\Exceptions;

class NotExistsException extends FileException {

}
