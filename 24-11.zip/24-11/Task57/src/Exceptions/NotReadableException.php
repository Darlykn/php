<?php

namespace App\Exceptions;

class NotReadableException extends FileException {

}
