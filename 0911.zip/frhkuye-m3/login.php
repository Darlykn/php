<?php
require_once('helpers.php');
require_once('function.php');
require_once('init.php');
$category_list = category_list($con);
$nav = include_template('categories.php', ['categories' => $category_list]);

$errors = [];
$required_fields = ['email', 'password'];
if (isset($_SESSION['is_auth']) && $_SESSION['is_auth']) {
    http_response_code(403);
    $detail = include_template('403.php', ['nav' => $nav]);
    print(include_template('layout.php', [
        'title' => '403',
        'nav' => $nav,
        'main' => $detail
    ]));
} else {
    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
        foreach ($required_fields as $field) {
            if (empty($_POST[$field])) {
                $errors[$field] = 'Поле не заполнено';
            }
        }

        if (!isset($errors['email']) && !filter_var($_POST['email'], FILTER_VALIDATE_EMAIL)) {
            $errors['email'] = 'Email должен быть корректным';
        }

        if (!isset($errors['email'])) {
            $user_get = get_user($_POST['email'], $con);
            if (!$user_get) {
                $errors['email'] = 'Данный email не зарегистрирован';
            }
        }
        if (!isset($errors['email']) && !isset($errors['password'])) {
                    if (!password_verify($_POST['password'], $user_get['password'])) {
                        $errors['password'] = 'Пароль введен неверно';

                    } else {

                        $_SESSION['username'] = $user_get['name'];
                        $_SESSION['is_auth'] = 1;
                        $_SESSION['id_user'] = $user_get['id'];
                        header('Location: /');
                    }
                }
    }

    $add_content = include_template('login-template.php', ['nav' => $nav, 'errors' => $errors]);
    print(include_template('layout.php', [

        'title' => 'Вход',
        'main' => $add_content,
        'nav' => $nav
    ]));
}