<?php
 session_start();

const HOSTNAME = "localhost";
const USER = "akhfvmxt";
const PASSWORD = "Tp83F6";
const DATABASE = "akhfvmxt_m3";

// const HOSTNAME = "got";
// const USER = "root";
// const PASSWORD = "";
// const DATABASE = "yeti";

$con = mysqli_connect(HOSTNAME, USER, PASSWORD, DATABASE);
mysqli_set_charset($con, "utf8");
