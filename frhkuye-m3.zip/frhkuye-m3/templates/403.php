<main>
<?=$nav?>
        <section class="lot-item container">
            <h2>403 Доступ закрыт</h2>
            <p>Данная страница недоступна.</p>
        </section>
</main>