<?php
require_once ('helpers.php');
require_once ('functions.php');
require_once ('init.php');

$categories = get_categories($con);
$nav = include_template('categories.php', ['categories' => $categories]);


$id = isset($_GET['id']) ? $_GET['id'] : -1;
$lots = lot_detail($con, $id);

if (http_response_code() === 404) {
    $detail_lot = include_template('404.php',['nav' => $nav]);
}else{
    $detail_lot = include_template('lot.php', ['nav' => $nav,
    'lots' => $lots]);
}

$layout = include_template('layout.php', [
    'title' => $lots['name'],
    'nav' => $nav,
    'main' => $detail_lot]);

print($layout);