<?php
session_start();

const HOSTNAME = "localhost";
const USER = "akhfvmxt";
const PASSWORD = "Tp83F6";
const BDNAME = "akhfvmxt_m3";


/*const HOSTNAME = "frhkuye-m3";
const USER = "root";
const PASSWORD = "";
const BDNAME = "bd";*/


$con = mysqli_connect(HOSTNAME, USER, PASSWORD, BDNAME);
mysqli_set_charset($con, "utf8");
// if ($con == false) {
//     print("Ошибка подключения: " . mysqli_connect_error());
// }
// else {
//     print("Соединение установлено");
//}
