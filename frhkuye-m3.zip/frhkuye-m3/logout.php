<?php
require_once ('init.php');
$_SESSION = [];
header("Location: /");
