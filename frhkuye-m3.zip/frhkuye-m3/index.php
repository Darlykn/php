<?php
require_once('functions.php');
require_once('helpers.php');
require_once('init.php');

$categories = get_categories($con);
$nav = include_template('categories.php', ['categories' => $categories]);

$main = include_template('main.php', [
    'lots' => get_lot($con),
    'categories' => $categories,
]);

$layout_content = include_template('layout.php', [
    'main' => $main,
    'title' => 'Главная',
    'nav' => $nav,
]);

print($layout_content);