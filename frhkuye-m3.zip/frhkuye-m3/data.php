<?php
$is_auth = rand(0, 1);
$user_name = 'Anastasia'; // укажите здесь ваше имя
$categories = ["Доски и лыжи", "Крепления", "Ботинки", "Одежда", "Инструменты", "Разное"];
$products = [
    [
        'name' => '2014 Rossignol District Snowboard',
        'category' => 'Доски и лыжи',
        'price' => 10999,
        'picture' => 'img/lot-1.jpg',
        'dateExpiry' => '2023-09-14'
    ],
    [
        'name' => 'DC Ply Mens 2016/2017 Snowboard',
        'category' => 'Доски и лыжи',
        'price' => 159999,
        'picture' => 'img/lot-2.jpg',
        'dateExpiry' => '2023-09-16'
    ],
    [
        'name' => 'Крепления Union Contact Pro 2015 года размер L/XL',
        'category' => 'Крепления',
        'price' => 8000,
        'picture' => 'img/lot-3.jpg',
        'dateExpiry' => '2023-09-17'
    ],
    [
        'name' => 'Ботинки для сноуборда DC Mutiny Charocal',
        'category' => 'Ботинки',
        'price' => 10999,
        'picture' => 'img/lot-4.jpg',
        'dateExpiry' => '2023-09-15'
    ],
    [
        'name' => 'Куртка для сноуборда DC Mutiny Charocal',
        'category' => 'Одежда',
        'price' => 7500,
        'picture' => 'img/lot-5.jpg',
        'dateExpiry' => '2023-09-17'
    ],
    [
        'name' => 'Маска Oakley Canopy',
        'category' => 'Разное',
        'price' => 5400,
        'picture' => 'img/lot-6.jpg',
        'dateExpiry' => '2023-09-16'
    ],
];
