INSERT INTO Category(name_category, sym_code) VALUES
    ('Доски и лыжи', 'boards'),
    ('Крепления', 'attachment'),
    ('Ботинки', 'boots'),
    ('Одежда', 'clothing'),
    ('Инструменты', 'tools'),
    ('Разное', 'other');

INSERT INTO User (date_reg, email, name, contact, password) VALUES
    ('2023-09-14 10:00:00', 'alexandr@mail.ru', 'Александр', 'Контакты пользователя','Alexandr1'),
    ('2023-09-14 11:00:00', 'anton@mail.ru', 'Антон', 'Контакты пользователя', 'Anton1'),
    ('2023-09-14 12:00:00', 'filip@mail.ru', 'Филипп', 'Контакты пользователя', 'Filip1');

INSERT INTO Lot (date_reg, name, description, picture, start_price, date_expiry, rate_step, creator_id, category_id) VALUES
    ('2023-09-15 12:00:00', '2014 Rossignol District Snowboard', 'Новый сноуборд в идеальном состоянии', 'img/lot-1.jpg', 10999, '2023-10-20', 50, 1, 1),
    ('2023-09-16 13:00:00', 'DC Ply Mens 2016/2017 Snowboard', 'Красный сноуборд', 'img/lot-2.jpg', 159999, '2023-10-21', 10, 2, 1),
    ('2023-09-17 12:00:00', 'Крепления Union Contact Pro 2015 года размер L/XL', 'Крепления в идеальном состоянии', 'img/lot-3.jpg', 8000, '2023-10-22', 50, 3, 2),
    ('2023-09-18 12:00:00', 'Ботинки для сноуборда DC Mutiny Charocal', 'Новые ботинки', 'img/lot-4.jpg', 10999, '2023-10-23', 50, 3, 3),
    ('2023-09-14 12:00:00', 'Куртка для сноуборда DC Mutiny Charocal', 'Новая куртка', 'img/lot-5.jpg', 7500, '2023-10-24', 50, 3, 4),
    ('2023-09-13 12:00:00', 'Маска Oakley Canopy', 'Маска в идеальном состоянии', 'img/lot-6.jpg', 5400, '2023-10-25', 50, 3, 5);

INSERT INTO Bet (date_reg, sum, lot_id, user_id) VALUES
     ('2023-09-15 14:00:00', 11049, 2, 1),
     ('2023-09-16 11:00:00', 160009, 1, 2);

-- Получить список всех категорий
SELECT * FROM Category;

-- Получить список лотов, которые еще не истекли, отсортированных по дате публикации (новые к старым)
SELECT
    l.name,
    l.start_price,
    l.picture,
    c.name_category,
    l.date_expiry
FROM Lot AS l
         INNER JOIN Category AS c ON l.category_id = c.id
WHERE l.date_expiry >= CURRENT_DATE
ORDER BY l.date_reg DESC;

-- Показать информацию о лоте по его ID
SELECT
    l.name,
    l.description,
    l.start_price,
    l.picture,
    c.name_category
FROM Lot AS l
         INNER JOIN Category AS c ON l.category_id = c.id
WHERE l.id = 1;

-- Обновить название лота по его идентификатору
UPDATE Lot
SET name = 'Лыжи'
WHERE id = 1; -- Замените на нужный ID лота

-- Получить список ставок для лота по его идентификатору с сортировкой по дате
SELECT
    b.date_reg,
    b.sum,
    l.name,
    u.name
FROM Bet AS b
         INNER JOIN Lot AS l ON b.lot_id = l.id
         INNER JOIN User AS u ON b.user_id = u.id
WHERE b.lot_id = 1
ORDER BY b.date_reg;
