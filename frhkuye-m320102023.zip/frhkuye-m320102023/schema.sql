CREATE TABLE Category(
    id INT PRIMARY KEY AUTO_INCREMENT,
    name_category VARCHAR(30) NOT NULL UNIQUE,
    sym_code VARCHAR(30) NOT NULL UNIQUE
);

CREATE TABLE User(
     id INT PRIMARY KEY AUTO_INCREMENT,
     date_reg TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
     email VARCHAR(300) NOT NULL UNIQUE,
     name VARCHAR(30) NOT NULL,
     contact VARCHAR(300) NOT NULL,
     password VARCHAR(300) NOT NULL
);

CREATE TABLE Lot(
     id INT PRIMARY KEY AUTO_INCREMENT,
     date_reg TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
     name VARCHAR(100) NOT NULL,
     description VARCHAR(500) NOT NULL,
     picture VARCHAR(255) NOT NULL,
     start_price INT NOT NULL,
     date_expiry DATE NOT NULL,
     rate_step INT NOT NULL,
     creator_id INT NOT NULL,
     winner_id INT,
     category_id INT NOT NULL,
     FOREIGN KEY (creator_id) REFERENCES User(id) ON DELETE CASCADE,
     FOREIGN KEY (winner_id) REFERENCES User(id),
     FOREIGN KEY (category_id) REFERENCES Category(id) ON DELETE CASCADE
);

CREATE TABLE Bet(
     id INT PRIMARY KEY AUTO_INCREMENT,
     date_reg TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
     sum INT NOT NULL,
     lot_id INT NOT NULL,
     user_id INT NOT NULL,
     FOREIGN KEY (lot_id) REFERENCES Lot(id) ON DELETE CASCADE,
     FOREIGN KEY (user_id) REFERENCES User(id) ON DELETE CASCADE
);