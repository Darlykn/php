<?php
require_once('functions.php');
require_once('helpers.php');
require_once('init.php');

const MAX_NAME_LENGHT = 100;
const MAX_DETAIL_LENGHT = 500;

$categories = get_categories($con);
$nav = include_template('categories.php', ['categories' => $categories]);

$errors = [];
$required_fields = ['lot-name', 'category', 'detail', 'lot-price', 'lot-step', 'lot-date'];

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    foreach ($required_fields as $field) {
        if (empty($_POST[$field])) {
            $errors[$field] = 'Поле не заполнено';
        }
    }

    if (!isset($errors['lot-date'])) {
        if (!is_date_valid($_POST['lot-date']) || time() >= strtotime($_POST['lot-date'])) {
            $errors['lot-date'] = 'Некорректная дата';
        }
    }

    if (!isset($errors['lot-price'])) {
        if (!filter_var($_POST['lot-price'], FILTER_VALIDATE_INT, array("options" => array("min_range" => 1)))) {
            $errors['lot-price'] = 'Цена должна быть натуральным числом';
        }
    }

    if (!isset($errors['lot-step'])) {
        if (!filter_var($_POST['lot-step'], FILTER_VALIDATE_INT, array("options" => array("min_range" => 1)))){
            $errors['lot-step'] = 'Ставка должна быть натуральным числом';
        }
    }


    if (!isset($errors['lot-name'])) {
        $len = strlen($_POST['lot-name']);
        if ($len > MAX_NAME_LENGHT) {
            $errors['lot-name'] = 'Значение должно быть меньше ' . MAX_NAME_LENGHT . ' символов';
        }
    }

    if (!isset($errors['detail'])) {
        $len = strlen($_POST['detail']);
        if ($len > MAX_DETAIL_LENGHT) {
            $errors['detail'] = 'Значение должно быть меньше ' . MAX_DETAIL_LENGHT . ' символов';
        }
    }

    $temp = time();

    //Обработка изображения
    if ($_FILES) {
        if ($_FILES['picture']['tmp_name'] !== "") {
            if (
                (mime_content_type($_FILES['picture']['tmp_name']) == "image/png") 
                || (mime_content_type($_FILES['picture']['tmp_name']) == "image/jpeg")
                || (mime_content_type($_FILES['picture']['tmp_name']) == "image/jpg")
            ) {
                $file_name = $_FILES['picture']['name'];
                $file_path = __DIR__ . '/uploads/';
                $file_url = '/uploads/' . $temp . $file_name;
                move_uploaded_file($_FILES['picture']['tmp_name'], $file_path . $temp . $file_name);
            } else {
                $errors['picture'] = "Изображение должно быть в формате *.png, *.jpeg или *.jpg";
            }
        } else {
            $errors['picture'] = "Добавьте изображение";
        }
    }
    if (empty($errors)) {


        $addLot = add_lot(
            $_POST['lot-name'],
            $_POST['detail'],
            '/uploads/' . $temp . $_FILES['picture']['name'],
            $_POST['lot-price'],
            $_POST['lot-date'],
            $_POST['lot-step'],
            $_POST['category'],
            $con
        );
       
        $page_content = header('Location: /lot.php?id=' . $addLot);
        exit();
        // $layout = include_template('layout.php', [
        //     'title' => 'Главная',
        //     'is_auth' => $is_auth,
        //     'user_name' => $user_name,
        //     'nav' => $nav,
        //     'main' => $page_content
        // ]);

        // print($layout);

    } else {
        $page_content = include_template('add-lot.php', ['errors' => $errors, 'nav' => $nav, 'categories' => $categories]);
        $layout = include_template('layout.php', [
            'title' => 'Главная',
            'is_auth' => $is_auth,
            'user_name' => $user_name,
            'nav' => $nav,
            'main' => $page_content
        ]);
        print($layout);
    }
}else{

$page_content = include_template('add-lot.php', ['errors' => $errors, 'nav' => $nav, 'categories' => $categories]);
$layout = include_template('layout.php', [
    'title' => 'Главная',
    'is_auth' => $is_auth,
    'user_name' => $user_name,
    'nav' => $nav,
    'main' => $page_content
]);
print($layout);
}
