<?php
const COUNT_SECONDS = 3600;
const COUNT_MINUTES = 60;
function formatSum($price) {
    return number_format($price, 0, '.', ' ').' ₽';
}

function timeEnd(string $dateExpiry): array{
    date_default_timezone_set('Asia/Yekaterinburg');
    $currentDate = time();
    $expiryDate = strtotime($dateExpiry.'+ 1 day'.'+ 1 minute');

    $hours = str_pad(floor(($expiryDate - $currentDate) / COUNT_SECONDS), 2, "0", STR_PAD_LEFT);
    $minutes =  str_pad(floor((($expiryDate -  $currentDate) % COUNT_SECONDS) / COUNT_MINUTES), 2, "0", STR_PAD_LEFT);
    return [$hours, $minutes];
}

function get_categories(mysqli $con): array{
    $sql = "SELECT * FROM Category";
    return mysqli_fetch_all(mysqli_query($con, $sql), MYSQLI_ASSOC);
}

function get_lot(mysqli $con): array{
    $sql = "SELECT Lot.id, `name`, `start_price`, `picture`, Category.name_category, `date_expiry`
        FROM `Lot` INNER JOIN Category ON Lot.category_id = Category.id
        WHERE date_expiry >= CURRENT_DATE 
        ORDER BY `date_reg` DESC";
    return mysqli_fetch_all(mysqli_query($con, $sql), MYSQLI_ASSOC);
}

function lot_detail(mysqli $con, int $id_lot): array|null
{
    $sql = "SELECT
    l.name,
    l.picture,
    l.start_price,
    l.date_expiry,
    l.description,
    c.name_category
    FROM Lot AS l
    INNER JOIN Category AS c ON l.category_id = c.id
    WHERE l.id = ?";
    
    $stmt = mysqli_prepare($con, $sql);
    mysqli_stmt_bind_param($stmt, 'i', $id_lot);
    mysqli_stmt_execute($stmt);
    $res = mysqli_stmt_get_result($stmt);
    $rows = mysqli_fetch_assoc($res);
    if(mysqli_num_rows($res) === 0){
        http_response_code(404);
    }
    return $rows;
}
function add_lot(
    string $name,
    string $description,
    string $picture,
    int $start_price,
    string $date_expiry,
    int $rate_step,
    int $category_id,
    mysqli $con
): int {
    $creator_id = 2;
    $sql = "INSERT INTO Lot( name, description, picture, start_price, date_expiry, rate_step, creator_id, category_id)
            VALUES ( ?,?,?,?,?,?,?,?)";
    $stmt = mysqli_prepare($con, $sql);
    mysqli_stmt_bind_param($stmt, 'sssisiii', $name, $description, $picture, $start_price, $date_expiry, $rate_step, $creator_id, $category_id);
    mysqli_stmt_execute($stmt);
    return $con->insert_id;
}

function getPostValue($name)
{
    return $_POST[$name] ?? "";
}